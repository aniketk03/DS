import java.rmi.Naming;

public class AddClient {
    public static void main(String args[]) {
        try {
            AddServerIntf obj = (AddServerIntf) Naming.lookup("rmi://localhost/AddServer");

            double d1 = 10;
            double d2 = 20;

            System.out.println("The first number is: " + d1);
            System.out.println("The second number is: " + d2);
            System.out.println("The sum is: " + obj.add(d1, d2));
        } catch (Exception e) {
            System.out.println("Client Exception: " + e);
        }
    }
}
